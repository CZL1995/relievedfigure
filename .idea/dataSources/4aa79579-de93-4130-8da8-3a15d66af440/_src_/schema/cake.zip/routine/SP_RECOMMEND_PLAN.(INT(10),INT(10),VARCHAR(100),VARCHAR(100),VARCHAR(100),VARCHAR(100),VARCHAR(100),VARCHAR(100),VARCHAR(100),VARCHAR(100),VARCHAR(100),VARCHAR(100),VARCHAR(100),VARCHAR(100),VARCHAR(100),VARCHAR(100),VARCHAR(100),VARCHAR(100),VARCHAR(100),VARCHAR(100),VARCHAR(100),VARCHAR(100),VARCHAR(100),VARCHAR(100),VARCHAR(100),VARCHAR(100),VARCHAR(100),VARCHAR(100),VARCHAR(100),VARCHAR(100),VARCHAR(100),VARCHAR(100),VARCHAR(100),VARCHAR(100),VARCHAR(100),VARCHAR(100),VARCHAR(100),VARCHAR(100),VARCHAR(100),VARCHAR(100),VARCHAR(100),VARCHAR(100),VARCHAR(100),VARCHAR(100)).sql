CREATE PROCEDURE SP_RECOMMEND_PLAN(IN IN_FLOW          INT(10), IN IN_VOICE INT(10), IN OUT_PLAN11 VARCHAR(100),
                                   IN OUT_TOTALFEE11   VARCHAR(100), IN OUT_PLAN12 VARCHAR(100),
                                   IN OUT_TOTALFEE12   VARCHAR(100), IN OUT_PLAN13 VARCHAR(100),
                                   IN OUT_TOTALFEE13   VARCHAR(100), IN OUT_FLOW11 VARCHAR(100),
                                   IN OUT_FLOWPRICE11  VARCHAR(100), IN OUT_VOICE11 VARCHAR(100),
                                   IN OUT_VOICEPRICE11 VARCHAR(100), IN OUT_PLANFEE11 VARCHAR(100),
                                   IN OUT_FLOW12       VARCHAR(100), IN OUT_FLOWPRICE12 VARCHAR(100),
                                   IN OUT_VOICE12      VARCHAR(100), IN OUT_VOICEPRICE12 VARCHAR(100),
                                   IN OUT_PLANFEE12    VARCHAR(100), IN OUT_FLOW13 VARCHAR(100),
                                   IN OUT_FLOWPRICE13  VARCHAR(100), IN OUT_VOICE13 VARCHAR(100),
                                   IN OUT_VOICEPRICE13 VARCHAR(100), IN OUT_PLANFEE13 VARCHAR(100),
                                   IN OUT_PLAN21       VARCHAR(100), IN OUT_TOTALFEE21 VARCHAR(100),
                                   IN OUT_PLAN22       VARCHAR(100), IN OUT_TOTALFEE22 VARCHAR(100),
                                   IN OUT_PLAN23       VARCHAR(100), IN OUT_TOTALFEE23 VARCHAR(100),
                                   IN OUT_FLOW21       VARCHAR(100), IN OUT_FLOWPRICE21 VARCHAR(100),
                                   IN OUT_VOICE21      VARCHAR(100), IN OUT_VOICEPRICE21 VARCHAR(100),
                                   IN OUT_PLANFEE21    VARCHAR(100), IN OUT_FLOW22 VARCHAR(100),
                                   IN OUT_FLOWPRICE22  VARCHAR(100), IN OUT_VOICE22 VARCHAR(100),
                                   IN OUT_VOICEPRICE22 VARCHAR(100), IN OUT_PLANFEE22 VARCHAR(100),
                                   IN OUT_FLOW23       VARCHAR(100), IN OUT_FLOWPRICE23 VARCHAR(100),
                                   IN OUT_VOICE23      VARCHAR(100), IN OUT_VOICEPRICE23 VARCHAR(100),
                                   IN OUT_PLANFEE23    VARCHAR(100))
  BEGIN
    SET OUT_PLAN11       = '4G自选套餐语音包88元档$4G自选套餐流量包70元档$+安心包';
    SET OUT_TOTALFEE11   = '每月费用$158元';
    SET OUT_PLAN12       = '4G飞享套餐158元档$+10元流量月包';
    SET OUT_TOTALFEE12   = '每月费用$168元';
    SET OUT_PLAN13       = '4G自选套餐语音包88元档$4G自选套餐流量包70元档';
    SET OUT_TOTALFEE13   = '每月费用$178元';
    SET OUT_FLOW11       = '2018MB';
    SET OUT_FLOWPRICE11  = '0.19元/M';
    SET OUT_VOICE11      = '501分钟';
    SET OUT_VOICEPRICE11 = '0.11元/分钟';
    SET OUT_PLANFEE11    = '151元';
    SET OUT_FLOW12       = '2028MB';
    SET OUT_FLOWPRICE12  = '0.29元/M';
    SET OUT_VOICE12      = '502分钟';
    SET OUT_VOICEPRICE12 = '0.12元/分钟';
    SET OUT_PLANFEE12    = '152元';
    SET OUT_FLOW13       = '2038MB';
    SET OUT_FLOWPRICE13  = '0.39元/M';
    SET OUT_VOICE13      = '503分钟';
    SET OUT_VOICEPRICE13 = '0.13元/分钟';
    SET OUT_PLANFEE13    = '153元';
    SET OUT_PLAN21       = '4G自选套餐语音包88元档$4G自选套餐流量包70元档$+安心包';
    SET OUT_TOTALFEE21   = '每月费用$118元';
    SET OUT_PLAN22       = '4G飞享套餐158元档$+10元流量月包';
    SET OUT_TOTALFEE22   = '每月费用$128元';
    SET OUT_PLAN23       = '4G自选套餐语音包88元档$4G自选套餐流量包70元档';
    SET OUT_TOTALFEE23   = '每月费用$138元';
    SET OUT_FLOW21       = '2041MB';
    SET OUT_FLOWPRICE21  = '1.29元/M';
    SET OUT_VOICE21      = '100分钟';
    SET OUT_VOICEPRICE21 = '1.19元/分钟';
    SET OUT_PLANFEE21    = '158元';
    SET OUT_FLOW22       = '2042MB';
    SET OUT_FLOWPRICE22  = '2.29元/M';
    SET OUT_VOICE22      = '200分钟';
    SET OUT_VOICEPRICE22 = '2.19元/分钟';
    SET OUT_PLANFEE22    = '258元';
    SET OUT_FLOW23       = '2043MB';
    SET OUT_FLOWPRICE23  = '3.29元/M';
    SET OUT_VOICE23      = '300分钟';
    SET OUT_VOICEPRICE23 = '3.19元/分钟';
    SET OUT_PLANFEE23    = '358元';
  END;
